﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_2db
{
    // Student.cs file

    public class Student
    {
        public string StudentID { get; set; }
        public string Password { get; set; }
        public string PhoneNumber { get; set; }
        public string StudentName { get; set; }
    }

}
