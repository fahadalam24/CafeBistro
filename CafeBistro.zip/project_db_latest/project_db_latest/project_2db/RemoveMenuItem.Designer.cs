﻿namespace project_2db
{
    partial class RemoveMenuItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ItemNametxt = new System.Windows.Forms.TextBox();
            this.descriptiontxt = new System.Windows.Forms.TextBox();
            this.pricetxt = new System.Windows.Forms.TextBox();
            this.categorytxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.o = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Removebtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ItemNametxt
            // 
            this.ItemNametxt.BackColor = System.Drawing.Color.SeaShell;
            this.ItemNametxt.ForeColor = System.Drawing.Color.IndianRed;
            this.ItemNametxt.Location = new System.Drawing.Point(302, 162);
            this.ItemNametxt.Name = "ItemNametxt";
            this.ItemNametxt.Size = new System.Drawing.Size(125, 27);
            this.ItemNametxt.TabIndex = 0;
            // 
            // descriptiontxt
            // 
            this.descriptiontxt.BackColor = System.Drawing.Color.SeaShell;
            this.descriptiontxt.ForeColor = System.Drawing.Color.SeaShell;
            this.descriptiontxt.Location = new System.Drawing.Point(302, 215);
            this.descriptiontxt.Name = "descriptiontxt";
            this.descriptiontxt.Size = new System.Drawing.Size(125, 27);
            this.descriptiontxt.TabIndex = 1;
            // 
            // pricetxt
            // 
            this.pricetxt.BackColor = System.Drawing.Color.SeaShell;
            this.pricetxt.ForeColor = System.Drawing.Color.IndianRed;
            this.pricetxt.Location = new System.Drawing.Point(302, 276);
            this.pricetxt.Name = "pricetxt";
            this.pricetxt.Size = new System.Drawing.Size(125, 27);
            this.pricetxt.TabIndex = 2;
            // 
            // categorytxt
            // 
            this.categorytxt.BackColor = System.Drawing.Color.SeaShell;
            this.categorytxt.ForeColor = System.Drawing.Color.IndianRed;
            this.categorytxt.Location = new System.Drawing.Point(302, 347);
            this.categorytxt.Name = "categorytxt";
            this.categorytxt.Size = new System.Drawing.Size(125, 27);
            this.categorytxt.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gill Sans MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.RosyBrown;
            this.label1.Location = new System.Drawing.Point(155, 165);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "ItemName";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Gill Sans MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.RosyBrown;
            this.label2.Location = new System.Drawing.Point(155, 222);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Description";
            // 
            // o
            // 
            this.o.AutoSize = true;
            this.o.Font = new System.Drawing.Font("Gill Sans MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.o.ForeColor = System.Drawing.Color.RosyBrown;
            this.o.Location = new System.Drawing.Point(155, 283);
            this.o.Name = "o";
            this.o.Size = new System.Drawing.Size(54, 25);
            this.o.TabIndex = 6;
            this.o.Text = "Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Gill Sans MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.RosyBrown;
            this.label4.Location = new System.Drawing.Point(155, 350);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Category";
            // 
            // Removebtn
            // 
            this.Removebtn.BackColor = System.Drawing.Color.AntiqueWhite;
            this.Removebtn.Font = new System.Drawing.Font("Ink Free", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Removebtn.ForeColor = System.Drawing.Color.IndianRed;
            this.Removebtn.Location = new System.Drawing.Point(555, 350);
            this.Removebtn.Name = "Removebtn";
            this.Removebtn.Size = new System.Drawing.Size(94, 34);
            this.Removebtn.TabIndex = 8;
            this.Removebtn.Text = "Remove";
            this.Removebtn.UseVisualStyleBackColor = false;
            this.Removebtn.Click += new System.EventHandler(this.Removebtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Gill Sans MT", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.RosyBrown;
            this.label3.Location = new System.Drawing.Point(239, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(335, 47);
            this.label3.TabIndex = 9;
            this.label3.Text = "Remove Menu Item";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.button1.Font = new System.Drawing.Font("Ink Free", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.IndianRed;
            this.button1.Location = new System.Drawing.Point(33, 60);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 29);
            this.button1.TabIndex = 10;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // RemoveMenuItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Removebtn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.o);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.categorytxt);
            this.Controls.Add(this.pricetxt);
            this.Controls.Add(this.descriptiontxt);
            this.Controls.Add(this.ItemNametxt);
            this.Name = "RemoveMenuItem";
            this.Text = "RemoveMenuItem";
            this.Load += new System.EventHandler(this.RemoveMenuItem_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox ItemNametxt;
        private TextBox descriptiontxt;
        private TextBox pricetxt;
        private TextBox categorytxt;
        private Label label1;
        private Label label2;
        private Label o;
        private Label label4;
        private Button Removebtn;
        private Label label3;
        private Button button1;
    }
}